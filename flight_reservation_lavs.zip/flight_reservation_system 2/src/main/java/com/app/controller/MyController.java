package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entity.GeoLocation;
import com.app.entity.Ticket;
import com.app.entity.User_Credentials;
import com.app.entity.User_Profile;
import com.app.repository.GeoLocationRepository;
import com.app.repository.TicketRepository;
import com.app.repository.UserCredentialRepository;
import com.app.repository.UserProfileRepository;

//import ch.qos.logback.core.model.Model;

@Controller
public class MyController {
	@Autowired
	UserProfileRepository userprofilerepo;
	@Autowired
	UserCredentialRepository usercredentialrepo;
	@Autowired
	TicketRepository ticketrepo;
	@Autowired
	GeoLocationRepository georepo;

//	@GetMapping("/adding")
//
//	public String greet() {
//		System.out.println("-========================================");
//		return "success";
//	}
//
//	@RequestMapping("/sdf")
//	public String hello() {
//		return "login";
//	}

//	@RequestMapping(value="/login",method=RequestMethod.GET)
//	@ResponseBody
	@GetMapping("/login")
	public String login(Model model,@RequestParam(value = "name") String name, @RequestParam(value="password") String password) 
	{
		try {
			User_Credentials c = new User_Credentials(name,password);
			System.out.println("hai");
			//return "register";
			 boolean flag=false;
				 List<User_Credentials> p3= (List<User_Credentials>) usercredentialrepo.findAll();
				 for(int i=0;i<p3.size();i++) {
					 
					 String n=p3.get(i).getName();
					 String p2=p3.get(i).getPassword();
					 if(n.equals(name) && p2.equals(password)) {
						 flag=true;
						 System.out.println("name: "+name+" password: "+password);
						 break;
					 }
				}
			if(flag)
			{
				model.addAttribute("msg", "User details saved successfully !");
				return "ticket";
			}
			else
			{
				model.addAttribute("msg", "New User !");
				//usercredentialrepo.save(c);
				return "register";
			}
		} //end of try block
		catch (Exception e) 
		{
			model.addAttribute("msg", "User details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
///-------/////
//	@RequestMapping(path = "/administratorCredentials/all", method = RequestMethod.GET)
//	@ResponseBody
//	public ArrayList<User_Credentials> getAllUser_Credentials() {
//		return (ArrayList<User_Credentials>) usercredentialrepo.findAll();
//	}
	/////-------------------/////
	
	@GetMapping("/registerpage")
	public String registration(Model model, @RequestParam(value = "id") Integer id,@RequestParam(value = "usertype") String usertype, @RequestParam(value = "password") String password,@RequestParam(value = "name") String name,
			@RequestParam(value = "dob") String dob, @RequestParam(value = "gender") String Gender,
			@RequestParam(value = "address") String Address, @RequestParam(value = "mobilenumber") Long MobileNumber,
			@RequestParam(value = "emailid") String EmailId) {
		try {
			System.out.println("id:" + id);
			System.out.println("name is " + name);
			

			
			
			User_Profile cp = new User_Profile(id,usertype,password, name, dob, Gender, Address, MobileNumber, EmailId);
			User_Credentials c = new User_Credentials(name,password);
			System.out.println("----------------------------------------------------------- +jdfksdjl");
			System.out.println("name is " + name);
			 boolean flag=false;
			List<User_Credentials> p3= (List<User_Credentials>) usercredentialrepo.findAll();
			for(int i=0;i<p3.size();i++) {
				
				String n=p3.get(i).getName();
				String p2=p3.get(i).getPassword();
				if(n.equals(name) && p2.equals(password)) {
					flag=true;
					System.out.println("name: "+name+" password: "+password);
					break;
				}
			}
			if(flag)
			{
				return "userexisting";
			}
			else {
				usercredentialrepo.save(c);
				userprofilerepo.save(cp);
				System.out.println("hai");
				model.addAttribute("msg", "User details saved successfully !");
				return "login";
			}
		} catch (Exception e) {
			model.addAttribute("msg", "User details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}

	@GetMapping("/ticket")
	public String login(Model model, @RequestParam(value = "id") Integer id,
			@RequestParam(value = "journeydate") String journeydate, @RequestParam(value = "source") String source,
			@RequestParam(value = "destination") String destination) {
		try {
			System.out.println("id:" + id);
			System.out.println("name is " + source);
			Ticket t = new Ticket(id, journeydate, source, destination);
			System.out.println("----------------------------------------------------------- +jdfksdjl");
			System.out.println("name is " + source);
			ticketrepo.save(t);
			System.out.println("hai");
			model.addAttribute("msg", "User details saved successfully !");
			
			//from here
			GeoLocation sc = georepo.findById(source).get();
			GeoLocation dc = georepo.findById(destination).get();
			

			double AVERAGE_RADIUS_OF_EARTH_KM = 6371;
			double userLat=sc.getLat();
			double userLng=sc.getLongitude();
			double venueLat=dc.getLat();
			double venueLng=dc.getLongitude();
			double latDistance = Math.toRadians(userLat - venueLat);
			double lngDistance = Math.toRadians(userLng - venueLng);
			double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
					+ Math.cos(Math.toRadians(userLat)) * Math.cos(Math.toRadians(venueLat))
					* Math.sin(lngDistance / 2) * Math.sin(lngDistance / 2);
			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
			double distance= (Math.round(AVERAGE_RADIUS_OF_EARTH_KM * c));
			String seatType="economy";
			double seatFare=0;
			double farePerKm=5;
			double travelDuration=(double)distance/800;
			switch(seatType){
			case "economy":
				seatFare=150;
				break;
			case "premiumEconomy":
				seatFare=250;
				break;
			case "business":
				seatFare=350;
				break;
				case "firstClass":
					seatFare=500;
					break;
			}
			Double ticketFair=(distance*farePerKm) + ( seatFare*travelDuration);
			model.addAttribute("ticketFare", ticketFair);

			System.out.print(ticketFair);
			
			//to here
			return "payment";
		} catch (Exception e) {
			model.addAttribute("msg", "User details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
	
	//payment
	@GetMapping("/payment")
	public String payment() {
		try {
			
			return "paymentsuccess";
		} catch (Exception e) {
			
			return "error";
		}
	}
	@GetMapping("/logout")
	public String logoutpage()
	{
		return "logout";
	}
}
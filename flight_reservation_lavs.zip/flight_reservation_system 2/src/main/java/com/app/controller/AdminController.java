package com.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entity.Admin_Credentials;
import com.app.repository.AdminCredentialsRepository;
import com.app.repository.AdminProfileRepository;
@Controller
public class AdminController {
	@Autowired
	AdminCredentialsRepository admincredentialsrepo;
	@Autowired
	AdminProfileRepository adminprofilerepo;
	@GetMapping("/alogin")
	
	public String login(Model model,@RequestParam(value = "name") String name, @RequestParam(value="password") String password) 
	{
		try {
			Admin_Credentials c = new Admin_Credentials(name,password);			
			System.out.println("hai");
			admincredentialsrepo.save(c);
			return "allFlights";
		} //end of try block
		catch (Exception e) 
		{
			model.addAttribute("msg", "Admin details couldn't be saved !");
			e.printStackTrace();
			return "error";
		}
	}
}
/*
//return "register";
//boolean flag=false;
//String a=(String)userType;
//if(a.equals("customer")) {
//	 List<Admin_Credentials> p3= (List<Admin_Credentials>) admincredentialsrepo.findAll();
//	 for(int i=0;i<p3.size();i++) {
//		 Integer n1=p3.get(i).getId();
//		 String n=p3.get(i).getName();
//		 String p2=p3.get(i).getPassword();
//		 if(n.equals(name) && p2.equals(password) && n1.equals(id)) {
//			 flag=true;
//			 System.out.println("name: "+name+" password: "+password);
//			 break;
//		 }
//	}
//}
//if(flag)
//{
//	model.addAttribute("msg", "User details saved successfully !");
//	return "ticket";
//}
//else
//{
//	model.addAttribute("msg", "New User !");
////	admincredentialsrepo.save(c);
//	return "aregister";
//}
//	@GetMapping("/aregisterpage")
//	public String registration(Model model, @RequestParam(value = "id") Integer id,@RequestParam(value = "usertype") String usertype, @RequestParam(value = "password") String password,@RequestParam(value = "name") String name,
//			@RequestParam(value = "dob") String dob, @RequestParam(value = "gender") String Gender,
//			@RequestParam(value = "address") String Address, @RequestParam(value = "mobilenumber") Long MobileNumber,
//			@RequestParam(value = "emailid") String EmailId) {
//		try {
//			System.out.println("id:" + id);
//			System.out.println("name is " + name);
//			
//
//			
//			
//			Admin_Profile cp = new Admin_Profile(id,usertype,password, name, dob, Gender, Address, MobileNumber, EmailId);
//			Admin_Credentials c = new Admin_Credentials(id,usertype,name,password);
//			System.out.println("----------------------------------------------------------- +jdfksdjl");
//			System.out.println("name is " + name);
//			 boolean flag=false;
//			List<Admin_Credentials> p3= (List<Admin_Credentials>) admincredentialsrepo.findAll();
//			for(int i=0;i<p3.size();i++) {
//				Integer n1=p3.get(i).getId();
//				String n=p3.get(i).getName();
//				String p2=p3.get(i).getPassword();
//				if(n.equals(name) && p2.equals(password) && n1.equals(id)) {
//					flag=true;
//					System.out.println("name: "+name+" password: "+password);
//					break;
//				}
//			}
//			if(flag)
//			{
//				return "userexisting";
//			}
//			else {
//				admincredentialsrepo.save(c);
//				adminprofilerepo.save(cp);
//				System.out.println("hai");
//				model.addAttribute("msg", "User details saved successfully !");
//				return "login";
//			}
//		} catch (Exception e) {
//			model.addAttribute("msg", "User details couldn't be saved !");
//			e.printStackTrace();
//			return "error";
//		}
//	}
 */


package com.app.controller;



import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entity.Flight;
import com.app.entity.Schedule;
import com.app.repository.ScheduleRepository;



@Controller
public class ScheduleController {
	@Autowired
	ScheduleRepository scheduleRepo;
	// Add & Modify
	@GetMapping("/insertschedule")
	public String insertSchedule(@RequestParam("schedule_Id") Integer schedule_Id,@RequestParam("flightname") String flight_name,@RequestParam("source") String source,@RequestParam("destination") String destination,@RequestParam("despatureDate") String despatureDate,@RequestParam("despatureTime") String despatureTime)
	{
		Schedule schedule=new Schedule(schedule_Id,flight_name, source, destination, despatureDate,despatureTime);
		scheduleRepo.save(schedule);
		return "schedulesuccess";
	}
	//view
	@GetMapping("/viewAllSchedules")
	public String viewSchedule(Model model) {
		List<Schedule> f = (ArrayList<Schedule>) scheduleRepo.findAll();
		model.addAttribute("schedules", f);
		return "allSchedule";
	}
	//
	//view
		@GetMapping("/viewselectSchedules")
		public String viewScheduledetails(Model model) {
			List<Schedule> f = (ArrayList<Schedule>) scheduleRepo.findAll();
			model.addAttribute("schedules", f);
			return "allSchedule";
		}
	
		
//		//viewandselect
//				@GetMapping("/viewselectSchedules")
//				public String viewScheduledetailssource(Model model) {
//					List<Schedule> f = (ArrayList<Schedule>) scheduleRepo.findAll();
//					for(int i=0;i<f.size();i++) {
//					String n=f.get(i).getSource();
//					String p2=f.get(i).getDestination();
//					
//					model.addAttribute("schedules", f);
//					return "allSchedulea";
//				}
			
		
	// delete
	@GetMapping("/deleteSchedule")
	
	public String deleteSchedule(@RequestParam("schedule_Id") Integer schedule_Id)
	{
		scheduleRepo.deleteById(schedule_Id);
		return "scheduledeleted";
	}
}

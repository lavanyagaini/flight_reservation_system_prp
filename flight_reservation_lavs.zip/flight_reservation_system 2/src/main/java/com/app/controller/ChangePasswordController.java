package com.app.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entity.Admin_Credentials;
import com.app.entity.Change_Password;
import com.app.entity.User_Credentials;
import com.app.repository.AdminCredentialsRepository;
import com.app.repository.ChangePasswordRepository;
import com.app.repository.UserCredentialRepository;

@Controller
public class ChangePasswordController {

//	@GetMapping("/changepassword")
//	public String changepassword(Model model, @RequestParam(value = "id") Integer id,
//			@RequestParam(value = "name") String name, @RequestParam(value = "password") String password) {
//
//		return "";
//	}
	@Autowired
	ChangePasswordRepository changepasswordRepo;
	@Autowired 
	UserCredentialRepository usercredentialrepo;
	@Autowired
	AdminCredentialsRepository admincredentialsRepo;
@GetMapping(path = "/forgotPassword")
public String changePassword(@RequestParam("usertype") String userType,@RequestParam("name") String name,@RequestParam("password") String password,@RequestParam("cpassword") String cpassword)
{
	boolean flag=false;
	List<Change_Password> password1= (List<Change_Password>) changepasswordRepo.findAll();
	for(int i=0;i<password1.size();i++) {
		System.out.println("forloop");
		String cp1=password1.get(i).getConfirmpassword();
		String cp2=password1.get(i).getPassword();
		if(cpassword.equals(password)) {
			flag=true;
			System.out.println("name: "+name+" password: "+password+" cpassword : "+cpassword);
			break;
		}
	}
	if(flag)
	{
		if (userType.equals("customer"))
		{
			User_Credentials c = new User_Credentials(name,password);
			usercredentialrepo.save(c);
			Change_Password cp = new Change_Password(userType, name,password,cpassword);
			changepasswordRepo.save(cp);
			return "passwordChanged";
		}
		else
		{
			Admin_Credentials c = new Admin_Credentials(name,password);
			admincredentialsRepo.save(c);
			return "passwordChanged";
		}
	}
	else
	{
		return "change1";
	}
	}
}
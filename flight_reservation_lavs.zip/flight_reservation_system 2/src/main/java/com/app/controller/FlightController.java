package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entity.Flight;
import com.app.repository.FlightRepository;

@Controller
public class FlightController {
	@Autowired
	FlightRepository flightRepo;

	// Add & Modify
	//@RequestMapping(path = "insertFlight")
	//@ResponseBody
	@GetMapping("/insertFlight")
	public String insertFlight(@RequestParam("flightname") String flight_name,
			@RequestParam("total_seats") Integer total_seats, @RequestParam("economy_seat") Integer economy_seats,
			@RequestParam("business_seats") Integer business_seats, @RequestParam("economy_seat_fare") Integer economy_seat_fare,
			@RequestParam("business_seat_fare") Integer business_seat_fare) {
		Flight flight = new Flight(flight_name, total_seats, economy_seats, business_seats, economy_seat_fare,
				business_seat_fare);
		flightRepo.save(flight);
		return "flightsuccess";
	}

	// view
	@GetMapping("/view")
	//@RequestMapping("/viewAllFlights")
	public String viewEmployees(Model model) {
		List<Flight> f = (ArrayList<Flight>) flightRepo.findAll();
		model.addAttribute("flights", f);
		return "allFlights";
	}

//	@RequestMapping(path = "/viewAllFlights", method = RequestMethod.GET)
//	@ResponseBody
//	public ArrayList<Flight> getAllFlights() {
//		return (ArrayList<Flight>) flightRepo.findAll();
//	}

	// delete
	//@RequestMapping(path = "/deleteFlight", method = RequestMethod.POST)
	//@ResponseBody
	@GetMapping("/deleteFlight")
	public String deleteFlight(@RequestParam("flightname") String flight_name) {
		flightRepo.deleteById(flight_name);
		return "flightdelete";
	}
}

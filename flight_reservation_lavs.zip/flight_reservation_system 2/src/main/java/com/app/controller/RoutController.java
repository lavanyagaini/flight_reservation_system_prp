package com.app.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.app.entity.Flight;
import com.app.entity.Route;
import com.app.repository.RouteRepository;

@Controller
public class RoutController {
	@Autowired
	RouteRepository RouteRepo;

	
	
	// Add & Modify
	@GetMapping("/insertroute")
	public String insertFlight(@RequestParam("id") Integer id,
			@RequestParam("source") String source, @RequestParam("distance") Integer distance,
			@RequestParam("destination") String destination, @RequestParam("costperkm") Integer costperkm,
			@RequestParam("duration") Integer duration)
	{
		Route route = new Route(id, source, destination, distance, duration,costperkm);
		RouteRepo.save(route);
		return "flightsuccess";
	}
	// view
	@GetMapping("/viewroute")
	
	public String viewEmployees(Model model) {
		List<Route> r = (ArrayList<Route>) RouteRepo.findAll();
		model.addAttribute("routes", r);
		return "allRoute";
	}


	// delete
	
	@GetMapping("/deleteroute")
	public String deleteFlight(@RequestParam("id") Integer fid) {
		RouteRepo.deleteById(fid);
		return "flightdelete";
	}
}

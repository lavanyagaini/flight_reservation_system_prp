package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Ticket {
@Id
private Integer cid;
private String source;
private String destination;
private String journeydate;
public Integer getCid() {
	return cid;
}
public void setCid(Integer cid) {
	this.cid = cid;
}
public String getSource() {
	return source;
}
public void setSource(String source) {
	this.source = source;
}
public String getDestination() {
	return destination;
}
public void setDestination(String destination) {
	this.destination = destination;
}
public String getDate() {
	return journeydate;
}
public void setDate(String date) {
	this.journeydate = date;
}
public Ticket(Integer cid, String source, String destination, String date) {
	super();
	this.cid = cid;
	this.source = source;
	this.destination = destination;
	this.journeydate = date;
}
public Ticket() {
	super();
	// TODO Auto-generated constructor stub
}
}

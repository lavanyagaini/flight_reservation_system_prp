package com.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="user_profile")
public class User_Profile {
@Id

private Integer user_id;
private String usertype;
private String password;

private String name;

private String dob;

private String gender;

private String address;

private Long mobilenumber;

private String emailid;

public String getUsertype() {
	return usertype;
}

public void setUsertype(String usertype) {
	this.usertype = usertype;
}


public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public User_Profile() {
	super();
	// TODO Auto-generated constructor stub
}

public Integer getUser_id() {
	return user_id;
}

public void setUser_id(Integer user_id) {
	this.user_id = user_id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDob() {
	return dob;
}

public void setDob(String dob) {
	this.dob = dob;
}

public String getGender() {
	return gender;
}

public void setGender(String gender) {
	this.gender = gender;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public Long getMobilenumber() {
	return mobilenumber;
}

public void setMobilenumber(Long mobilenumber) {
	this.mobilenumber = mobilenumber;
}

public String getEmailid() {
	return emailid;
}

public void setEmailid(String emailid) {
	this.emailid = emailid;
}

public User_Profile(Integer user_id, String usertype, String password, String name, String dob, String gender,
		String address, Long mobilenumber, String emailid) {
	super();
	this.user_id = user_id;
	this.usertype = usertype;
	this.password = password;
	this.name = name;
	this.dob = dob;
	this.gender = gender;
	this.address = address;
	this.mobilenumber = mobilenumber;
	this.emailid = emailid;
}






}

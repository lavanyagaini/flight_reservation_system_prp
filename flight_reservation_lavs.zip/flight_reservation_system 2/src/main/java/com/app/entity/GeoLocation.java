package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class GeoLocation {
	@Id
	private String id;
	private String statename;
	private String airportname;
	private Double lat;
	private Double longitude;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getStatename() {
		return statename;
	}
	public void setStatename(String statename) {
		this.statename = statename;
	}
	public String getAirportname() {
		return airportname;
	}
	public void setAirportname(String airportname) {
		this.airportname = airportname;
	}

	public Double getLat() {
		return lat;
	}
	public void setLat(Double lat) {
		this.lat = lat;
	}
	public Double getLongitude() {
		return longitude;
	}
	public void setLongitude(Double longitude) {
		this.longitude = longitude;
	}
	
	public GeoLocation(String id, String statename, String airportname, Double lat, Double longitude) {
		super();
		this.id = id;
		this.statename = statename;
		this.airportname = airportname;
		this.lat = lat;
		this.longitude = longitude;
	}
	@Override
	public String toString() {
		return "GeoLocation [id=" + id + ", statename=" + statename + ", airportname=" + airportname + ", lat=" + lat
				+ ", longitude=" + longitude + "]";
	}
	public GeoLocation() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

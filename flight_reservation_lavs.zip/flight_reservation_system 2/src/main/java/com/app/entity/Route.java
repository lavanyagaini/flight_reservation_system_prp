package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Route {
	@Id
	private Integer id;
	private String source;
	private String destination;
	private Integer distance;
	private Integer duration;
	private Integer costperkm;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Integer getDistance() {
		return distance;
	}
	public void setDistance(Integer distance) {
		this.distance = distance;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}
	public Integer getCostperkm() {
		return costperkm;
	}
	public void setCostperkm(Integer costperkm) {
		this.costperkm = costperkm;
	}
	public Route(Integer id, String source, String destination, Integer distance, Integer duration, Integer costperkm) {
		super();
		this.id = id;
		this.source = source;
		this.destination = destination;
		this.distance = distance;
		this.duration = duration;
		this.costperkm = costperkm;
	}
	public Route() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Flight {
	@Id
	private String flingt_name;
	private Integer total_seats;
	private Integer economy_seat;
	private Integer business_seats;
	private Integer economy_seat_fare;
	private Integer business_seat_fare;
	public String getFlingt_name() {
		return flingt_name;
	}
	public void setFlingt_name(String flingt_name) {
		this.flingt_name = flingt_name;
	}
	public Integer getTotal_seats() {
		return total_seats;
	}
	public void setTotal_seats(Integer total_seats) {
		this.total_seats = total_seats;
	}
	public Integer getEconomy_seat() {
		return economy_seat;
	}
	public void setEconomy_seat(Integer economy_seat) {
		this.economy_seat = economy_seat;
	}
	public Integer getBusiness_seats() {
		return business_seats;
	}
	public void setBusiness_seats(Integer business_seats) {
		this.business_seats = business_seats;
	}
	public Integer getEconomy_seat_fare() {
		return economy_seat_fare;
	}
	public void setEconomy_seat_fare(Integer economy_seat_fare) {
		this.economy_seat_fare = economy_seat_fare;
	}
	public Integer getBusiness_seat_fare() {
		return business_seat_fare;
	}
	public void setBusiness_seat_fare(Integer business_seat_fare) {
		this.business_seat_fare = business_seat_fare;
	}
	public Flight(String flingt_name, Integer total_seats, Integer economy_seat, Integer business_seats,
			Integer economy_seat_fare, Integer business_seat_fare) {
		super();
		this.flingt_name = flingt_name;
		this.total_seats = total_seats;
		this.economy_seat = economy_seat;
		this.business_seats = business_seats;
		this.economy_seat_fare = economy_seat_fare;
		this.business_seat_fare = business_seat_fare;
	}
	public Flight() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}

package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Schedule {
	@Id
	private Integer schedule_Id;
	private String flight_name;
	private String source;
	private String destination;
	private String despatureDate;
	private String despatureTime;
	public Integer getSchedule_Id() {
		return schedule_Id;
	}
	public void setSchedule_Id(Integer schedule_Id) {
		this.schedule_Id = schedule_Id;
	}
	public String getFlight_name() {
		return flight_name;
	}
	public void setFlight_name(String flight_name) {
		this.flight_name = flight_name;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public String getDespatureDate() {
		return despatureDate;
	}
	public void setDespatureDate(String despatureDate) {
		this.despatureDate = despatureDate;
	}
	public String getDespatureTime() {
		return despatureTime;
	}
	public void setDespatureTime(String despatureTime) {
		this.despatureTime = despatureTime;
	}
	public Schedule(Integer schedule_Id, String flight_name, String source, String destination, String despatureDate,
			String despatureTime) {
		super();
		this.schedule_Id = schedule_Id;
		this.flight_name = flight_name;
		this.source = source;
		this.destination = destination;
		this.despatureDate = despatureDate;
		this.despatureTime = despatureTime;
	}
	public Schedule() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}

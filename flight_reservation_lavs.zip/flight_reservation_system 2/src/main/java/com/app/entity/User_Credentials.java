package com.app.entity;



import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class User_Credentials {
	@Id
	private String name;
	private String password;
	


@Override
	public String toString() {
		return "User_Credentials [name=" + name + ", password=" + password + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

public User_Credentials(){}

public User_Credentials(String name, String password) {
	super();
	this.name = name;
	this.password = password;
}

}

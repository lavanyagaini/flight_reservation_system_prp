package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity

public class Change_Password {
	
	private String userType;
	@Id
	private String name;
	private String password;
	private String confirmpassword;

	public Change_Password(String userType, String name, String password, String confirmpassword) {
		super();
		
		this.userType = userType;
		this.name = name;
		this.password = password;
		this.confirmpassword = confirmpassword;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	

	public String getUserType() {
		return userType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Change_Password() {
	}

	public Change_Password(String name, String password) {
		this.name = name;
		this.password = password;
	}

}

package com.app.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="passenger_details")
public class Passenger_Details {
private String name;
private Integer age;
private String gender;
@Id
private Integer seat_no;
private Character seat_type;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public Integer getAge() {
	return age;
}
public void setAge(Integer age) {
	this.age = age;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
public Integer getSeat_no() {
	return seat_no;
}
public void setSeat_no(Integer seat_no) {
	this.seat_no = seat_no;
}
public Character getSeat_type() {
	return seat_type;
}
public void setSeat_type(Character seat_type) {
	this.seat_type = seat_type;
}
public Passenger_Details(String name, Integer age, String gender, Integer seat_no, Character seat_type) {
	super();
	this.name = name;
	this.age = age;
	this.gender = gender;
	this.seat_no = seat_no;
	this.seat_type = seat_type;
}

}

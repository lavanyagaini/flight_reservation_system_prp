package com.app.entity;

import javax.persistence.Entity;

import javax.persistence.Id;

@Entity
public class Admin_Credentials {
	@Id
	private String name;
	private String password;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	public Admin_Credentials(String name, String password) {
		super();
		this.name = name;
		this.password = password;
	}
	public Admin_Credentials() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}


package com.app.database;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entity.GeoLocation;
import com.app.repository.GeoLocationRepository;

@Controller
public class GeoLocationDataBase {
	@Autowired
	GeoLocationRepository geoLocationRepo;
	@GetMapping("/GeoData")
	@ResponseBody
	public String GeoDataInsertion() {
		GeoLocation data = new GeoLocation("IXZ","Andaman and Nicobar","Port Blair",11.6234,92.7265);
		geoLocationRepo.save(data);
		data=new GeoLocation("VTZ", "Andhra Pradesh", "Visakhapatnam", 17.6868,83.2185);
		geoLocationRepo.save(data);
		data=new GeoLocation("GAU", "Assam", "Guwahati", 26.1158,91.7086);
		geoLocationRepo.save(data);
		data=new GeoLocation ("PAT", "Bihar", "Patna", 25.5941,85.1376);
		geoLocationRepo.save(data);
		data=new GeoLocation ("DEL", "Delhi", "New Delhi", 28.6139,77.2090);
		geoLocationRepo.save(data);
		data=new GeoLocation ("GOI", "Goa", "Goa", 15.2993,74.1240);
		geoLocationRepo.save(data);
		data=new GeoLocation ("AMD", "Gujarat", "Ahmedabad", 23.0225,72.5714);
		geoLocationRepo.save(data);
		data=new GeoLocation ("SXR", "Jammu and Kashmir", "Srinagar", 34.0837,74.7973);
		geoLocationRepo.save(data);
		data=new GeoLocation ("BLR", "Karnataka", "Bengaluru", 12.9716,77.5946);
		geoLocationRepo.save(data);
		data=new GeoLocation ("COK", "Kerala", "Kochi", 9.9312,76.2673);
		geoLocationRepo.save(data);
		data=new GeoLocation ("IDR", "Madhya Pradesh", "Indore", 22.7196,75.8577);
		geoLocationRepo.save(data);
		data=new GeoLocation ("BOM", "Maharashtra", "Mumbai", 19.0760,72.8777);
		geoLocationRepo.save(data);
		data=new GeoLocation ("IMF", "Manipur", "Imphal", 24.8170,93.9368);
		geoLocationRepo.save(data);
		data=new GeoLocation ("SHL", "Meghalaya", "Shillong", 25.5788,91.8933);
		geoLocationRepo.save(data);
		data=new GeoLocation ("BBI", "Odisha", "Bhubaneswar", 20.2961,85.8245);
		geoLocationRepo.save(data);
		data=new GeoLocation ("ATQ", "Punjab", "Amritsar", 31.6340,74.8723);
		geoLocationRepo.save(data);
		data=new GeoLocation ("JAI", "Rajasthan", "Jaipur", 26.9124,75.7873);
		geoLocationRepo.save(data);
		data=new GeoLocation ("MAA", "Tamil Nadu", "Chennai", 13.0827,80.2707);
		geoLocationRepo.save(data);
		data=new GeoLocation ("HYD", "Telangana", "Hyderabad", 17.3850,78.4867);
		geoLocationRepo.save(data);
		data=new GeoLocation ("LKO", "Uttar Pradesh", "Lucknow", 26.8467,80.9462);
		geoLocationRepo.save(data);
		data=new GeoLocation ("CCU", "West Bengal", "Kolkata", 22.5726,88.3639);
		geoLocationRepo.save(data);
		return "hello";
		/*@RequestParam("city_code") String city_code,
        @RequestParam("state") String state,
        @RequestParam("city") String city,
        @RequestParam("latitude") Double latitude,
        @RequestParam("longitude") Double longitude*/
	}
}
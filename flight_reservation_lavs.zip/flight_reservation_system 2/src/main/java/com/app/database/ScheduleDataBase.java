package com.app.database;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.app.entity.Schedule;
import com.app.repository.ScheduleRepository;

@Controller
public class ScheduleDataBase {
	@Autowired
	ScheduleRepository scheduleRepo;
	@GetMapping("/ScheduleData")
	@ResponseBody
	public String ScheduleDataInsertion() {
		Schedule schedule = new Schedule(1, "indigo", "HYD", "BBI", "20-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(1, "indigo", "HYD", "BBI", "20-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(2, "indigo", "BBI", "COK", "20-MAR-2023", "12:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(3, "indigo", "COK", "AMD", "20-MAR-2023", "15:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(4, "indigo", "HYD", "BBI", "20-MAR-2023", "20:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(5, "airAsia", "HYD", "BBI", "20-MAR-2023", "11:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(6, "airAsia", "COK", "AMD", "20-MAR-2023", "14:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(7, "indigo", "HYD", "BBI", "21-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		schedule = new Schedule(8, "indigo", "HYD", "BBI", "20-MAR-2023", "09:00");
		scheduleRepo.save(schedule);
		return "schedule success";
		}
}

package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Change_Password;
public interface ChangePasswordRepository extends CrudRepository<Change_Password,Integer>{

}

package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Schedule;

public interface ScheduleRepository extends CrudRepository<Schedule, Integer>{

}

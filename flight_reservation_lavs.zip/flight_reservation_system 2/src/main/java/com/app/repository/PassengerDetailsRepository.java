package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Passenger_Details;

public interface PassengerDetailsRepository extends CrudRepository<Passenger_Details,Integer>{

}

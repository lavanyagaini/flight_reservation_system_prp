package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Admin_Profile;

public interface AdminProfileRepository extends CrudRepository<Admin_Profile,Integer>{

}

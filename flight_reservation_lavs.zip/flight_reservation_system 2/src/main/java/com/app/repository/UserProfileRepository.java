package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.User_Profile;

public interface UserProfileRepository extends CrudRepository<User_Profile,Integer> {

	

}

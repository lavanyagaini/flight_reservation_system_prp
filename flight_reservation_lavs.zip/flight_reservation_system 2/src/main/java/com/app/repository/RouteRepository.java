package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Route;

public interface RouteRepository extends CrudRepository<Route,Integer>{

}

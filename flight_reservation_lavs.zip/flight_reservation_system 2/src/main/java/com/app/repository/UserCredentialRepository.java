package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.User_Credentials;
public interface UserCredentialRepository extends CrudRepository<User_Credentials,String>{

}

package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Flight;

public interface FlightRepository extends CrudRepository<Flight,String>{

}

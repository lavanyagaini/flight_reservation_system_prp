package com.app.repository;

import org.springframework.data.repository.CrudRepository;


import com.app.entity.Admin_Credentials;

public interface AdminCredentialsRepository extends CrudRepository<Admin_Credentials,Integer>{

}

package com.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.app.entity.Ticket;

public interface TicketRepository extends CrudRepository<Ticket,Integer>{

}
